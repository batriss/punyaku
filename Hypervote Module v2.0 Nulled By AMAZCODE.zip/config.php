<?php if ( ! defined( 'APP_VERSION' ) ) { die( "Yo, what's up?" ); }

	return [
		'idname'            => 'massvoting',
		'plugin_name'       => 'Hypervote Massvoting',
		'plugin_uri'        => 'https://amazcode.ooo',
		'author'            => 'AMAZCODE',
		'author_uri'        => 'https://amazcode.ooo',
		'version'           => '2.0',
		'desc'              => 'Very useful module for voting Instagram Stories. The module has advanced targeting options and Task Manager system.',
		'icon_style'        => 'color: #fff; background-color: #2b69e9; font-size: 18px; line-height: 18px;',
		'settings_page_uri' => APPURL . '/e/massvoting/settings',
	];
